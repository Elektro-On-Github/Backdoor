Qui ci sono tutti i file prima di essere stati compilati.
I file sono stati compilati per essere eseguiti come admin