#il file da compilare si deve chiamare 'backdoor.ps1'
#e deve essere nella directory dello script!
#esegui come admin lo script

set-executionpolicy unrestricted -force
Install-Module ps2exe
ps2exe .\backdoor.ps1 .\porticina.exe
